var DATASET_ID = 'ciwm29xyd00082tmocm5l6osb';
var DATASETS_BASE = 'https://api.mapbox.com/datasets/v1/chennaiflood/' + DATASET_ID + '/';
var DATASETS_ACCESS_TOKEN = 'sk.eyJ1IjoiY2hlbm5haWZsb29kIiwiYSI6ImNpaG9mOGljdTBibmN0aGo3NWR6Y3Q0aXQifQ.X73YugnJDlhZEhxz2X86WA';
var PUBLIC_ACCESS_TOKEN = 'pk.eyJ1IjoicGxhbmVtYWQiLCJhIjoiemdYSVVLRSJ9.g3lbg_eN0kztmsfIPxa9MQ';
var STYLESHEET = 'mapbox://styles/planemad/cih4qzr0w0012awltzvpie7qa';
var LOAD_INFO_LAYERS = ['chennai-relief-camps', 'chennai-relief-camps-22nov'];